1. virtualenv venv
2. venv/Scripts/activate
3. pip install -r requirements.txt
4. python main.py